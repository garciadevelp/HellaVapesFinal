<?php
   include('head.php');
?>
    <title>Hella Vapes: Juice</title>
    <header>
     <div id="positiondiv">
     <img src="images/juiceheader.png" alt=" Juice Header" width="100%">
     <div id="headingtext"><h1>Shop Juice</h1></div>
    </div>
    </header>
    
<?php
       include('main-nav.html');
?>
        
    <div id="content">
       
<!--Juice categories table-->         
        <table id="juice-categories">
            <td>
                <h2>Free-Base Juice</h2><br>
                <a href="freebase.php"><img src="Images/free.jpg" alt="free-base category" width="100%" height="100%"></a>
            </td>
            <td>
                <h2>Salt-Nic Juice</h2><br>
                <a href="saltnic.php"><img src="Images/salt.jpg" alt="salt-nic category" width="100%" height="100%"></a>
            </td>
        </table>
        
        <div id="backtotop"><a href="#main-nav">Back to Top</a></div>
        
        </div>
        
<?php
    include('footer.php');
?>