    <footer><p id="dev-tag">Created by <a href="https://garciadevelop.com/" target="_blank">Garcia Develop</a></p>
                <p id="copywrite">Copyright © 2019 · All Rights Reserved · Hella Vapes</p>
    </footer>
    <script src="js/hella.js"></script>
    <script src="js/jquery-ui.min.js"></script>  
    
   </body>
   
</html>