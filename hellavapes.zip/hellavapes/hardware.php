<?php
    session_start();
   include('head.php');
?>
   <title>Hella Vapes: Hardware</title>
    <header>
        <div id="positiondiv">
        <img src="images/hardwareheader.png" alt=" Hardware Header" width="100%">
         <div id="headingtext"><h1>Shop Hardware</h1></div>
        </div>
    </header>
    
<?php
     include('main-nav.html');
?>
      
<!--Hardware categories table-->      
       <div id="content">
        
        <table id="hardware-categories">
            <tr>
                <td><h2>Sub-Ohm Kits</h2><br>
                <a href="sub-ohm.php"><img src="Images/vapes.png" alt="vapes category" width="100%" height="100%"></a>
                </td>
                <td>
                    <h2>All-In-One Kits</h2><br>
                    <a href="all-in-one.php"><img src="Images/aio.jpg" alt="all-in-one category" width="100%" height="100%"></a>
                </td>
                <td id="block"><h2>Mods</h2><br>
                <a href="mods.php"><img src="Images/mods.jpg" alt="mods category" width="100%" height="100%"></a>
                </td>
            </tr>
            <tr>
                <td id="htablet">
                     <h2>Tanks</h2><br>
                <a href="tanks.php"><img src="Images/tanks.jpg" alt="tanks category" width="100%" height="100%"></a>
                </td>
                <td id="htablet">
                    <h2>Mods</h2><br>
                    <a href="mods.php"><img src="Images/mods.jpg" alt="mods category" width="100%" height="100%"></a>
                </td>
            </tr>
            <tr>
            <td id="block">
               <h2>Tanks</h2><br>
                <a href="tanks.php"><img src="Images/tanks.jpg" alt="tanks category" width="100%" height="100%"></a>
            </td>
               <td>
                   <h2>Coils</h2><br>
                   <a href="coils.php"><img src="Images/coils.jpg" alt="coils category" width="100%" height="100%"></a>
               </td>
                <td>
                   <h2>Parts</h2><br>
                    <a href="parts.php"><img src="Images/acc.jpg" alt="acccessories category" width="100%" height="100%"></a>
                </td>

            </tr>
        </table>
        
        <div id="backtotop"><a href="#main-nav">Back to Top</a></div>
        
        </div>
        
<?php
    include('footer.php');
?>