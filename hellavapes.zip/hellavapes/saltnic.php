<?php
    session_start();
   include('head.php');
?>
    <title>Hella Vapes: Salt Nicotine Juice</title>
            <header>
             <div id="positiondiv">
             <img src="images/saltheader.png" alt=" Salt Header" width="100%">
             <div id="headingtext"><h1>Salt Nicotine</h1></div>
            </div>
            </header>
    
<?php
       include('main-nav.html');
        require_once("dbcontroller.php");
        $db_handle = new DBController();
?>
        
    <div id="content">

<!--Displaying products with category 8-->
	<?php
	$product_array = $db_handle->runQuery("SELECT * FROM products2 where category_id = 8 ORDER BY product_name");
    ?><table id="producttable"><tr><?php 
	if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
    <!--Displaying each product in its own submit form--->
			<form method="post" action="cart.php?action=add&code=<?php echo $product_array[$key]["code"]; ?>">
			<td>
			<h2><?php echo $product_array[$key]["product_name"]; ?></h2><br>
			<img src="<?php $image = $product_array[$key]["image_name"];
            $image_src = "images/".$image; echo "$image_src"; ?>"><br>
            <?php echo "<span id='price'>$".$product_array[$key]["price"]; '</spam>' ?>
            <input type="text" class="product-quantity" id="pquantity" name="quantity" value="1" size="2" /><br>
             <p id="pdescription"><strong>Description: </strong><?php echo $product_array[$key]["description"]; ?></p><br>
			<input type="submit" value="Add to Cart" id="add2"/>
            </td>   
			</form><!--End Product Form-->

     <?php
		}
	   }
        ?>
	</tr></table>
     <div id="backtotop"><a href="#main-nav">Back to Top</a></div>
        
</div><!--Content-->
        
<?php
    include('footer.php');
?>