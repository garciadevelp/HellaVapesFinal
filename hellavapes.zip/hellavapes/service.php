<?php
session_start();
    include('head.php');
?>
    
    <title>Hella Vapes: Contact</title>
    <header>
     <div id="positiondiv">
     <img src="images/contactheader.png" alt=" Contact Header" width="100%">
     <div id="headingtext"><h1>Contact Hella Vapes</h1></div>
    </div>
    </header>

<?php
    include('main-nav.html');
?>

    <div id="content">
        
        <?php
        ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);
        //Disabling unwanted "Notice".
        
        include('config.php');
/*Recieving contact form information*/
        if(isset($_POST['send'])){
           
            $cfname = $_POST["cfname"];
            $clname = $_POST["clname"];
            $ccid = $_POST["ccidn"];   
            $subject = $_POST["ctopic"];
            $senderemail = $_POST["cemail"];
            $cmessage = mysqli_real_escape_string($db ,$_POST["cmessage"]);
            $cmessageclense = addslashes($cmessage);

            $sql = "INSERT INTO messages (m_id, cf_name, cl_name, ccid, c_subject, c_emailaddress, c_message) VALUES (NULL,'$cfname', '$clname', '$ccid', '$subject', '$senderemail', '$cmessageclense')"; // Insert query
        
/*Checking if insert was successful*/
            if(mysqli_query($db, $sql)){
                echo '<p id="sent_message">Thank you for contacting Hella Vapes. One of our admins will be in touch shortly through the email you\'ve provided.</p>';
            } else{
                echo "ERROR: Was not able to execute $sql. Please try again later " . mysqli_error($db);
            }

        mysqli_close($db);

        /*Hiding contact form if submitted*/
        } else{ ?>
        
            <form id="contact" method="post" action=" ">
            <label for="cfname">First Name *</label><br>
            <input type="text" name="cfname" id="cfname" pattern="[a-zA-Z]{1,}" required><br>
            
            <label for="clname">Last Name *</label><br>
            <input type="text" name="clname" id="clname" pattern="[a-zA-Z]{1,}" required><br>
            
            <label for="cemail">Email *</label><br>
            <input type="email" name="cemail" id="cemail" required><br>
            
            <label for="ccog" id="ccoglabel">Entering your customer ID will help speed up the process of our response.</label><br>
            
            <input onclick="document.getElementById('custom').disabled = false; document.getElementById('charstype').disabled = true;" type="radio" name="type" checked="checked">Returning Customer

            <input onclick="document.getElementById('custom').disabled = true; document.getElementById('charstype').disabled = false;" type="radio" name="type" value="customurl">Guest<br>
            
            <input type="text" name="ccidn" id="custom" placeholder="Enter customer ID *" pattern="[a-zA-Z0-9 ]{2,35}]" required>
            
            <label for="ctopic">Topic *</label><br>
              <select name="ctopic" id="ctopic" required>
                    <option value="">Select...</option>
                    <option value="account">Account</option>
                    <option value="orders">Orders</option>
                    <option value="device_help">Device Help</option>
                    <option value="other">Other</option>
              </select><br>
              
              <label for="cmessage">Message *</label><br>
              <textarea name="cmessage" id="cmessage" form="contact" placeholder="Enter message here..." required></textarea><br>
              <input type="submit" id="submit" name="send" value="Send Message">
        </form>
        
        <div id="backtotop"><a href="#main-nav">Back to Top</a></div><?php }?>
        
    </div><!--Content-->
        
<?php
    include('footer.php');
?>