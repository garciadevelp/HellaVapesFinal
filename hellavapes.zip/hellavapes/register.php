 <?php
    session_start();
    include('head.php');
?>
    <title>Hella Vapes: Registration</title>
        <header>
        <div id="positiondiv">
        <img src="images/registerheader.png" alt=" Registration Header" width="100%">
         <div id="headingtext"><h1>Registration</h1></div>
        </div>
        </header>

<?php
    include('main-nav.html');
?>  
<?php 
    include('config.php');

/*Recieving registration form information*/
    if(isset($_POST['register'])){

        $fname = $_POST["rfname"];
        $lname = $_POST["rlname"];
        $email = $_POST["remail"];
        $address = $_POST["raddress"];
        $city = $_POST["rcity"];
        $state = $_POST["rstate"];
        $zipcode = $_POST["rzipcode"];
        $userlevel = 1;

        /*Password Encription*/
        $pword = md5($_POST["rpword"]); 
        
        /*Checking if email has already been used*/
        $sql = "SELECT * FROM users WHERE email_address = '$email'";
        $result = mysqli_query($db,$sql);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);

      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
          $emailasso = "<p id='sent_message'>Email is already associated with an account.</p>";
          echo $emailasso;
          echo "<div id='addb'><a href='login.php' id='add'>Login ?</a></div>";
      } else {
        
        

          $sql = "INSERT INTO users (user_id, first_name, last_name, email_address, acct_password, address, city, state, zipcode, user_level) VALUES (NULL,'$fname', '$lname', '$email', '$pword', '$address', '$city', '$state', '$zipcode', '$userlevel')"; 

          /*Checking if insert was successful*/
          if(mysqli_query($db, $sql)){
            echo "<p id='sent_message'>You have successfuly registered!</p>";
              echo "<div id='addb'><a href='login.php' id='add'>Login</a></div>";
          } else{
              echo "ERROR: Please try again$sql. " . mysqli_error($db);
            echo "<a href='register.php'>Try Again</a>";
            }
        }
      }
    

mysqli_close($db);
?>       
    <div id="content">
      <!--Registration form-->
       <?php if(!isset($_POST['register'])) {?>
         <form id="registration" method="post" action=" ">
             <label for="rfname">First Name *</label><br>
             <input type="text" name="rfname" id="rfname" pattern="[a-zA-Z]{1,}" required value="<?php if (isset($_POST['rfname'])) echo $_POST['rfname']; ?>"><br>
             
             <label for="rlname">Last Name *</label><br>
             <input type="text" name="rlname" id="rlname" pattern="[a-zA-Z]{1,}" required value="<?php if (isset($_POST['rlname'])) echo $_POST['rlname']; ?>"><br>
             
             <label for="remail">Email *</label><br>
             <input type="email" name="remail" id="remail" required value="<?php if (isset($_POST['remail'])) echo $_POST['remail']; ?>"><br>
             
             <label for="raddress">Address *</label><br>
             <input type="text" name="raddress" id="raddress" pattern="[a-zA-Z0-9 ]{2,35}]" required value="<?php if (isset($_POST['raddress'])) echo $_POST['raddress']; ?>"><br>
             
             <label for="rcity">City *</label><br>
             <input type="text" name="rcity" id="rcity" pattern="[a-zA-Z]{1,}" required value="<?php if (isset($_POST['rcity'])) echo $_POST['rcity']; ?>"><br>
             
             <label for="rstate">State *</label><br>
              <select name="rstate" id="rstate" required value="<?php if (isset($_POST['rstate'])) echo $_POST['rstate']; ?>">
                    <option value="">Select...</option>
                    <option value="AL">Alabama</option>
	                <option value="AK">Alaska</option>
	                <option value="AZ">Arizona</option>
	                <option value="AR">Arkansas</option>
	                <option value="CA">California</option>
	                <option value="CO">Colorado</option>
	                <option value="CT">Connecticut</option>
	                <option value="DE">Delaware</option>
	                <option value="DC">District Of Columbia</option>
	                <option value="FL">Florida</option>
	                <option value="GA">Georgia</option>
	                <option value="HI">Hawaii</option>
	                <option value="ID">Idaho</option>
	                <option value="IL">Illinois</option>
	                <option value="IN">Indiana</option>
	                <option value="IA">Iowa</option>
	                <option value="KS">Kansas</option>
	                <option value="KY">Kentucky</option>
	                <option value="LA">Louisiana</option>
	                <option value="ME">Maine</option>
	                <option value="MD">Maryland</option>
	                <option value="MA">Massachusetts</option>
	                <option value="MI">Michigan</option>
	                <option value="MN">Minnesota</option>
	                <option value="MS">Mississippi</option>
	                <option value="MO">Missouri</option>
	                <option value="MT">Montana</option>
	                <option value="NE">Nebraska</option>
	                <option value="NV">Nevada</option>
	                <option value="NH">New Hampshire</option>
	                <option value="NJ">New Jersey</option>
	                <option value="NM">New Mexico</option>
	                <option value="NY">New York</option>
	                <option value="NC">North Carolina</option>
	                <option value="ND">North Dakota</option>
	                <option value="OH">Ohio</option>
	                <option value="OK">Oklahoma</option>
	                <option value="OR">Oregon</option>
	                <option value="PA">Pennsylvania</option>
	                <option value="RI">Rhode Island</option>
	                <option value="SC">South Carolina</option>
	                <option value="SD">South Dakota</option>
	                <option value="TN">Tennessee</option>
	                <option value="TX">Texas</option>
	                <option value="UT">Utah</option>
	                <option value="VT">Vermont</option>
	                <option value="VA">Virginia</option>
	                <option value="WA">Washington</option>
	                <option value="WV">West Virginia</option>
	                <option value="WI">Wisconsin</option>
	                <option value="WY">Wyoming</option>
              </select><br>
              
              <label for="rzipcode">Zipcode *</label><br>
              <input type="text" name="rzipcode" id="rzipcode" pattern="(\d{5}([\-]\d{4})?)" required value="<?php if (isset($_POST['rzipcode'])) echo $_POST['rzipcode']; ?>"><br>
             
             <label for="rpword">Password *</label><br>
             <input type="password" name="rpword" id="rpword" onkeyup='check();' placeholder="No more than 12 characters" pattern=".{1,12}" required><br>
             
             <label for="rpword2">Repeat Password *</label><br>
             <input type="password" name="rpword2" id="rpword2" onkeyup='check();' required><br>
             <span id='message'></span>
             
             <input type="submit" id="register" name="register" value="Register">
             
        </form>


<div id="backtotop"><a href="#main-nav">Back to Top</a></div>
<?php }?>

<!--Checking if passwords match script-->
<script>
var check = function() {
  if (document.getElementById('rpword').value ==
    document.getElementById('rpword2').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'Matching';
    document.getElementById("register").disabled = false;
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Not matching';
    document.getElementById("register").disabled = true;
  }
} 
</script>

</div><!--Content-->
       
<?php 
    include('footer.php');
?>