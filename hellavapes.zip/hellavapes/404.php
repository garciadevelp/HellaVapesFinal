<?php
    session_start();
   include('head.php');
?>
    <title>Hella Vapes: Free-Base Juice</title>
        <header>
             <div id="positiondiv">
             <img src="images/404error.png" alt="404 Header" width="100%">
             <div id="headingtext"><h1>404 Error</h1></div>
            </div>
            </header>
    
<?php
       include('main-nav.html');
?>
        
 <div id="content">
 
     <p id="sent_message">404 Page URL Error</p>
         
</div>
<?php 
    include('footer.php');
?>