<?php
    session_start();
   include('head.php');
?>
    <title>Hella Vapes: Q and A</title>
    <header>
     <div id="positiondiv">
     <img src="images/qandaheader.png" alt=" Juice Header" width="100%">
     <div id="headingtext"><h1>Q and A</h1></div>
    </div>
    </header>
    
<?php
       include('main-nav.html');
?>
        
<div id="content">
    <h2>Search for Commonly Asked Questions</h2>
    <p id="ccoglabel2"><strong>Examples: </strong>'Atomizer', 'Smoking', 'Leaking', etc...</p>
    <!--Search Form-->
		<form method="POST" action="" id="qandaf">
			<input type="text" name="searchbar" placeholder="Enter topic keyword..." required>
			<input type="submit" name="search" id="searchbar" value="Search">
		</form>

<!--Recieving and displaying search results-->
<?php
include_once('config.php');
if(isset($_POST['search'])){
	$q = mysql_real_escape_string($_POST['searchbar']);
	$sql = "SELECT * FROM qanda Where question LIKE '%".$q."%'"; 
        $result = mysqli_query($db,$sql);
      $count = mysqli_num_rows($result);

	   if($count != 0) {
        ?><table id="qandatable"><tr><?php
           /*Displaying each answer associated*/
            while ($row = $result->fetch_assoc()) {
            $field1name = $row["question"];
            $field2name = $row["answer"];?>

                <td><h7><?php echo $field1name; ?></h7><br>
                    <p id="qandaa"><strong>Answer: </strong><?php echo $field2name; ?></p><br>
              </td>
<?php } ?>
       
        </tr></table>
        <div id='center'><a id="btnempty" href="service.php">Still need help?</a></div><?php
        } else {
        echo "<div id='center'><span id='sent_message'>Sorry, no results. </span><a id='btnempty' href='service.php'>Contact customer service?</a></div>";
        }
	}?>
   
   </div><!--Content-->
    
<?php    
    include("footer.php");
?>

