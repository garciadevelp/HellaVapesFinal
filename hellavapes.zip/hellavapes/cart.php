<?php
    session_start();
    include('head.php');
?>
    <title>Hella Vapes: Cart</title>
    <header>
     <div id="positiondiv">
     <img src="images/cartheader.png" alt=" Cart Header" width="100%">
    <div id="headingtext"><h1>Shopping Cart</h1></div>
    </div>
    </header>

<?php
    include('main-nav.html');
?>
        
    <div id="content">
       <h2>Your Cart Items</h2>
       
        <?php
        /*Acquiring added to cart product information*/
        require_once("dbcontroller.php");
        $db_handle = new DBController();
        if(!empty($_GET["action"])) {
            switch($_GET["action"]) {
	           case "add":
		      if(!empty($_POST["quantity"])) {
			     $productByCode = $db_handle->runQuery("SELECT * FROM products2 WHERE code='" . $_GET["code"] . "'");
			     $itemArray = array($productByCode[0]["code"]=>array('product_name'=>$productByCode[0]["product_name"], 'code'=>$productByCode[0]["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["price"], 'image_name'=>$productByCode[0]["image_name"]));
			
			   if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode[0]["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode[0]["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
?>



<?php

if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	

       <div id="adddiv2">
       <!--Empty cart button-->
       <a id="btnempty" href="cart.php?action=empty">Empty Cart?</a></div>

<!--Products added to cart table-->
<table id="carttable">
    <thead>
        <tr>
            <th><!--Blank heading for image--></th>
            <th>Product</th>
            <th>Code</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Price</th>
            <th>Remove?</th>
        </tr>
    </thead>	
    <tbody>
    <?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><img id="cartimg" src="<?php $image = $item["image_name"];
                $image_src = "images/".$image; echo "$image_src"; ?>"></td><td>
                <?php echo $item["product_name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td><?php echo $item["quantity"]; ?></td>
				<td><?php echo "$ ".$item["price"]; ?></td>
				<td><?php echo "$ ". number_format($item_price,2); ?></td>
				<td><a href="cart.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction"><img src="icon-delete.png" alt="Remove Item" /></a></td>
				</tr>

				<?php
                /*Cart total table criteria*/
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		      }?>
               
    </tbody>
</table>
				
<!--Cart total table-->
<table id="carttabletotal">	
    <thead>
        <tr>
            <th>Items</th>
            <th>Price</th>
        <tr>
    </thead>
    <tbody>
        <tr>
            <td align="right"><?php echo $total_quantity; ?></td>
            <td align="right"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
        </tr>
    </tbody>
</table>
       
<div id="bottombtns">
    <a id="paypalbtn" href="https://www.paypal.com/us/home" target="_blank"><img src="images/ppicon.png"></a><br>
    <?php if(!isset($_SESSION['access'])){?>
    <a id="cartlogin" href="login.php">Login?</a><?php }
?></div>
    	
  <?php
    /*Empty cart message*/
    } else {
    ?>
    <div class="no-records" id="sent_message">Your Cart is Empty</div>
    <?php 
    }?>
    
</div><!--Content Div-->
        
<?php
    include('footer.php');
?>