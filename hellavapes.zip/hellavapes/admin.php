<?php
session_start();
include('head.php');

/*Checking for admin user level*/
if(isset($_SESSION['access']))
{
    if($_SESSION['access'] != 3)
    {
        header('location: profile.php');
    }
} else {
    header('location: login.php');
}


?>
<title>Hella Vapes: Admin Operations</title>
<header>
     <div id="positiondiv">
     <img src="images/adminheader.png" alt=" Admin Header" width="100%">
     <div id="headingtext"><h1>Admin Operations</h1></div>
    </div>
</header>

     <?php
       include('main-nav.html');
       ?>
       
       <div id="content">
       
<!--Recieving add new product form submission-->
  <?php 
    if(isset($_POST['padd'])){        
        $ptitle = $_POST['ptitle'];
        $pdescription = mysqli_real_escape_string($db ,$_POST["description"]);
        $pprice = $_POST['pprice'];
        $pcategory = $_POST['pcategory'];
        $code = $_POST['code'];
        $img = $_FILES['image']['name'];
        
        $sql = "INSERT INTO products2 (id, product_name, description, price, category_id, image_name, code) VALUES (NULL, '$ptitle', '$pdescription', '$pprice', '$pcategory', '$img','$code')"; // Insert query
        
        if(mysqli_query($db, $sql)){
            move_uploaded_file($_FILES['image']['tmp_name'], "images/$img");
                echo "<p id='sent_message'>You have successfuly added '".$ptitle."'</p>";
                echo "<div id='adddiv'><a href='admin.php #newproduct' id='add'>+ Another</a></div>";
            
        } else{
                echo "ERROR: Please try again$sql. " . mysqli_error($db);
}

mysqli_close($db);
    } else {
?>

<!--Add new product form-->
<h2>Add a New Product</h2>

<p id="ccoglabel2">* All Fields Are Required</p>        
  <form id="newproduct" method="post" action=" " enctype="multipart/form-data">
            <input type="text" placeholder="Title" id="ptitle" name="ptitle" pattern="[a-zA-Z0-9 ]{2,35}]" required><br>
            <label  for="pprice">$</label>
            <input type="number" id="pprice" step='0.01' name="pprice" placeholder="0.00" pattern='[0-9]+(\\.[0-9][0-9]?)?'  required><br>
            <label  for="pcategory">Category: </label>
              <select name="pcategory" id="pcategory" required>
                    <option value="">Select...</option>
                    <option value="1">Sub-Ohm Kits</option>
                    <option value="2">All-in-One Kits</option>
                    <option value="3">Mods</option>
                    <option value="4">Tanks</option>
                    <option value="5">Coils</option>
                    <option value="6">Parts</option>
                    <option value="7">Free-Base Nicotine</option>
                    <option value="8">Salt Nicotine</option>
                  </select><br>
                <input type="file" id="pimage" name="image" accept="image/*" required><br>
                <input type="text" placeholder="Product code" id="code" name="code" pattern="[a-zA-Z0-9 ]{2,35}]" required><br>
                <textarea id="pdescription" placeholder="Product description..." name="pdescription" required></textarea><br>   
      <div id="addb"><input type="submit" id="padd" name="padd" value="Add Product"></div>
  </form>

<?php } ?>


</div><!--Content-->


<?php
    include('footer.php');
?>