<!--Include recaptcha javascript-->
<script src="https://www.google.com/recaptcha/api.js?render=6LeOLJ8UAAAAAHraS69zhXH1NcqZ0yLt75zSxZUR"></script>


<!--Recaptcha token-->
 <script>      
  grecaptcha.ready(function() {
      grecaptcha.execute('6LeOLJ8UAAAAAHraS69zhXH1NcqZ0yLt75zSxZUR', {action: 'homepage'}).then(function(token) {
    var recaptchaResoonse = document.getElementById('recaptchaResponse');
        recaptchaResponse.value = token;
      });
  });
</script>
 
  <?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
       
       /*Checking recaptcha*/
       $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
       $recaptcha_secret = '6LeOLJ8UAAAAANUE08D0_Y_1NcX24-L8H7DExAJE';//site key, not secret
       $recaptcha_response = $_POST['recaptcha_response'];
       $recaptcha = file_get_contents($recaptcha_url. '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
       
       $recaptcha = json_decode($recaptcha);
       
       if($recaptcha->success) {
        
      
        $myusername = $_POST['username'];
        $mypassword = md5($_POST['password']); 
      
        $sql = "SELECT * FROM users WHERE email_address = '$myusername' and acct_password = '$mypassword'";
        $result = mysqli_query($db,$sql);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $active = $row['active'];
      
        $count = mysqli_num_rows($result);

      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
          
         $_SESSION['access'] = $row['user_level'];
          
          if($_SESSION['access'] != 3) {
            header('location: profile.php');
            } else 
          if ($_SESSION['access'] == 3){
                header("location: admin.php");
            } else  {header('Location: index.php');}//Admin If
      }
          else {
            $invalid = "<p id='invalid'>Email or Password Invalid</p>";
          }
          }/*If recaptcha fail*/
          else {
            echo "Recaptcha Fail.";
            }//Recaptcha Fail
 }
?>

<?php
    include('head.php');
?>
    <title>Hella Vapes: Account Login</title>
    <header>
     <div id="positiondiv">
     <img src="images/loginheader.png" alt=" Login Header" width="100%">
     <div id="headingtext"><h1>Account Login</h1></div>
    </div>
</header>
    
<?php
    include('main-nav.html');
?>
               <div id="content">
               
<!--Login Form-->
                <form id="loginform" action = "" method = "post">
                  <label>Email  :</label><input type = "email" name = "username" class = "box" value="<?php if (isset($_POST['username'])) echo $_POST['username']; ?>"/><br /><br />
                  <label>Password  :</label><input type = "password" pattern=".{1,12}" name = "password" class = "box" /><br/><br />
                  <input type="hidden" name="recaptcha_response" id="recaptchaResponse" value="">
                  <input type = "submit" value = "Submit"/><br />
               </form>
               
              <?php if($_SERVER["REQUEST_METHOD"] == "POST")  {
                   echo $invalid;}?><!--If credentials invalid-->
                </div>

<?php 
       include('footer.php');
?>