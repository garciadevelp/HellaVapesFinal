
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Customer Profile for Hella Vapes">
        <link rel="stylesheet" href="css/hella.css"> 
        <script src="js/hella.js"></script>
        <script src="js/jquery-ui.min.js"></script>  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">   
    </head>
   
    <body>
        
         <div id="top-bar">
             <a href="index.php"><image src="images/hellalogo.png" alt="Hella Logo" id="logo" height="70px"></image></a>
             <nav id="top-nav">
<!--Top nav for guest-->             
           <?php 
             if(!isset($_SESSION['access'])){?>
            <a href="login.php">Login</a> 
            <a href="register.php">Register</a>
            <a href="cart.php">Cart</a><?php 
             }?>
 
<!--Top nav for regular user-->            
             <?php
                if(isset($_SESSION['access'])) {
                    include('session.php');
                    if($_SESSION['access'] == 1){
                        ?><a href="profile.php">Profile</a>
                        <a href="cart.php">Cart</a>
                        <a href="logout.php">Logout: <?php echo '<span id="logoutname">' .$firstname. '</span>'?></a><?php
                    }
                }?>
                
<!--Top nav for admin-->
            <?php
                if(isset($_SESSION['access'])) {
                    if($_SESSION['access'] == 3){
                        ?><a href="profile.php">Profile</a>
                        <a href="admin.php">Admin Operations</a>
                        <a href="cart.php">Cart</a>
                        <a href="logout.php">Logout: <?php echo '<span id="logoutname">' .$firstname. '</span>'?></a><?php
                    }
                }?>
            
            
         </nav>
        </div>

        <div id="warning">
          <p>Warning: This Product Contains Nicotine. Nicotine is an Addictive Chemical.</p>
        </div>