<?php
session_start();
include('head.php');

/*If not logged in, redirecting to login page*/
if(!isset($_SESSION['access']))
{
        header('location: login.php');
    }

?>
    <title>Hella Vapes: Customer Profile</title>
        <header>
        <div id="positiondiv">
        <img src="images/profileheader.png" alt=" Profile Header" width="100%">
         <div id="headingtext"><h1>User Profile</h1></div>
        </div>
        </header>

     <?php
       include('main-nav.html');
       ?>
       
       <div id="content">
           <h2 id="profilehead">Thank You for Being a Valued Customer</h2>
           <p id="profilesub">Your Saved Information</p>
       <?php

           echo '<div id="savedpi"><p id="profilename">' .$firstname. ' ' .$lastname. '</p>';
            echo '<p id="uid"> Customer ID: '.$login_session.'</p>';
           echo '<p id="pemail"> Email: '.$email.'</p></div>';
         ?>
       </div>

<?php
    include('footer.php');
?>