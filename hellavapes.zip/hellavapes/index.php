<?php 
session_start();
   include('head.php');
?>
    
    <title>Hella Vapes: Home</title>
    <header> 
    
<!-- Slideshow container -->
        <div class="slideshow-container">

          <!-- Full-width images with number and caption text -->
          <div class="mySlides fade">
            <div class="numbertext">1 / 4</div>
            <img src="Images/banner1.jpg" style="width:100%">
          </div>

          <div class="mySlides fade">
            <div class="numbertext">2 / 4</div>
            <img src="Images/banner3.jpg" style="width:100%">
          </div>

          <div class="mySlides fade">
            <div class="numbertext">3 / 4</div>
            <img src="Images/banner4.jpg" style="width:100%">
          </div>
  
          <div class="mySlides fade">
            <div class="numbertext">4 / 4</div>
            <img src="Images/banner2.jpg" style="width:100%">
          </div>

        </div>
    </header>
<br>

<?php
      include('main-nav.html');
?>
       
       <div id="content">
       
<!--Welcome paragraph-->
        
        <h4>Welcome to Hella Vapes!</h4>
        <p id="homep">Hella Vapes isn't just a website, it's a community... Register for an account with us and recieve tech support and other information that could change your life as a vaper. Not a vaper yet? Trying to quit smoking? We're here to help! Recieve 20% off your first starter kit with a brand new account, and we'll also throw in a new vaper pamplet explaing how the transition process works, containing vape special tips, and success stories of how others successfully quit smoking because of vaping. Already a vaper? Register for an account and recieve 10% off your first purchase just for joining. Again, welcome to our commmunity!</p>
        
<!--New products-->        
        <h3>New Products</h3>
        <hr id="line">
        <table id="newest">
                <td><h2>Smok Nord</h2><br>
                <img src="images/nord.jpg"><br>
                 <a href="all-in-one.php#main-nav" id="view">View</a>
                </td>
                <td>
                    <h2>Vaporesso Luxe ZV Kit</h2><br>
                    <img src="images/luxe.jpg"><br>
                    <a href="sub-ohm.php#main-nav" id="view">View</a>
                </td>
                <td>
                    <h2>Voopoo Drag Resin Skin</h2><br>
                    <img src="images/skin.jpg"><br>
                    <a href="parts.php#main-nav" id="view">View</a>
                </td>
        </table>
        
<!--Weekly Sale-->        
        <h3>Weekly Juice Sale</h3>
        <hr id="line">
        <div id="salediv">
        <p id="sales">Add this promo code to PayPal at checkout: DXKY76LN0Q</p>
        <a href="freebase.php#content">        
        <img src="images/nakedsale.png" id="saleimg">
        <img src="images/mobilenakedsale.jpg" id="msaleimg"></a>
           </div>
        
<!--Customer Reviews-->        
        <h3>Customer Reviews</h3>
        <hr id="line">
        <table id="reviews">
               <td>
                <img src="images/review1.jpg"><br>
                <p id="dname">TheVapeKing092117</p><br>
                <p id="reviewp">Hella Vapes helped me quit smoking after having been smoking for 3 years.
                The Hella Vapes team walked me through the entire initial setup of my new device.</p>
                </td>
               <td>
                <img src="images/review2.jpg"><br>
                <p id="dname">CloudChaser863</p><br>
                <p id="reviewp">Products coming from Hella Vapes are always accurate, fast shipping, 
                and in perfect condition. User manuals are very descriptive.</p>                
                </td>
               <td>
                <img src="images/review3.jpg"><br>
                <p id="dname">ChainPuffer3648</p><br>
                <p id="reviewp">Hella Vape's customer service representatives are always fast
                at replying to my messages, especially when I can't use my device until they can help. </p>
                </td>
        </table>
        
        </div>
        
    <div id="backtotop"><a href="#main-nav">Back to Top</a></div>

<!--Slider Script-->
<script>var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 4000); 
}</script>
        
<?php
    include('footer.php');
?>