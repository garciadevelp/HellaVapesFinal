<?php
include('config.php');
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($db,"select * from users where email_address = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['user_id'];
    $firstname = $row['first_name'];
    $lastname = $row['last_name'];
    $email = $row['email_address'];
    $address = $row['address'];
    $city = $row['city'];
    $state = ['state'];
    $zipcode = ['zipcode'];
   
?>